/* Generated automatically by makepackage. Any changes made here will be lost. */
#define SERNO "win32-production"
