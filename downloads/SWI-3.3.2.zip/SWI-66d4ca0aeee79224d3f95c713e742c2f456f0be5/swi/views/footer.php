		<!-- 
			// SWI - Services Web Interface (v3)
			// Additional Functionality, Bug Fixes, Cosmetic Fixes and more by 
			// siniStar @ Xtheme.org
		-->

		<footer id="copyright">[ <a href="<?php print base_url(); ?>" target="_top"><img src=<?php print base_url(); ?>ico/world.png></a> <?php if ($this->config->item('social_media')) : ?>| <a href="<?php print $this->config->item('fb_url'); ?>" target="_blank"><img src=<?php print base_url(); ?>ico/facebook.png></a> | <a href="<?php print $this->config->item('tw_url'); ?>" target="_blank"><img src=<?php print base_url(); ?>ico/twitter.png></a><?php endif; ?> ] &nbsp;&nbsp;&nbsp; <a href="http://www.Xtheme.org/SWI/" target="_top">Services Web Interface</a> (<a href="http://www.Xtheme.org/SWI/" target="_top">SWI <?php print $this->config->item('swi_vers'); ?></a>) [<b><a href="<?php print site_url('main/credits'); ?>"><?php _t('gen_swicredits'); ?></a></b>]</footer>
	</div>
</body>
</html>
