<?php $this->load->view('header'); ?>
	<?php $this->load->view('navigation'); ?>
	
		<!-- The content -->
		<section id="content">
			
			<div>
				<h2><img src=<?php print base_url(); ?>ico/comment.png> Staff Messages</h2>
<p><form>
<section>
	<label>MM/DD/YYYY> Message title</label> </section><div> <small>Start you message here...<br><br> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; - Sincerely<br> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;- YourNetwork Team</div>
<section>
	<label>MM/DD/YYYY> Message title</label> </section><div> <small>Here's a message...<br><br> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; - Enjoy!<br> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;- YourNetwork Team</div>
<section>
	<label>MM/DD/YYYY> Password Safety</label> </section><div> <small>Be sure to <u>never</u> give out your password to anyone claiming to be YourNetwork Staff or Operators.  We will <u>never</u> ask you for your password.<br><br> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; - Chat Safely!<br> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;- YourNetwork Staff</div>
</form>
	
	
</p>
			</div>
			

			</div>
			
			<div class="clear">&nbsp;</div>
		</section>
	</div>
          
<?php $this->load->view('footer'); ?>