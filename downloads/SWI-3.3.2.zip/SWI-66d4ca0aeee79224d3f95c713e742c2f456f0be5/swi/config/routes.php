<?php  if (!defined('BASEPATH')) exit('No direct script access allowed');


$route['default_controller'] 	= "main";
$route['login']                 = "main";
$route['logout']                = "main/logout";
$route['register']              = "main/register";
$route['404_override'] 			= '';
