package Atheme::Account;

use strict;
use warnings;

use Atheme::Entity;

our @ISA = qw/Atheme::Entity/;

1;
