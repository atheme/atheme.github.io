/*
 * Copyright (c) 2005-2010 William Pitcock <nenolod@atheme.org>.
 * Rights to this code are as documented in doc/LICENSE.
 *
 * Initialization stub for libathemecore.
 */

#include "libathemecore.h"

int main(int argc, char *argv[])
{
	return atheme_main(argc, argv);
}
