package Atheme::Object;

use strict;
use warnings;

1;
